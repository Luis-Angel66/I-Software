const express = require('express');
const AdminController = require('../controllers/adminController');
const admin = require('../config/firebase');

const router = express.Router();
const adminController = new AdminController(admin.firestore());

// Admin routes
router.post('/', adminController.createAdmin.bind(adminController));
router.get('/:id', adminController.getAdmin.bind(adminController));
router.delete('/:id', adminController.deleteAdmin.bind(adminController));

module.exports = router;