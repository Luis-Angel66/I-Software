const express = require('express');
const UserController = require('../controllers/userController');
const admin = require('../config/firebase');
const db = admin.firestore();

const router = express.Router();
const userController = new UserController(admin);

// User routes
router.post('/', userController.createUser.bind(userController));
router.post('/login', userController.loginUser.bind(userController));
router.get('/:uid', userController.getUser.bind(userController));
router.delete('/:uid', userController.deleteUser.bind(userController));
router.put('/:uid', userController.updateUser.bind(userController)); // <--- NUEVA RUTA PARA EDITAR USUARIO

module.exports = router;