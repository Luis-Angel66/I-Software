const express = require('express');
const DonationController = require('../controllers/donationController');
const admin = require('../config/firebase');

const router = express.Router();
const donationController = new DonationController(admin.firestore());

// Donation routes
router.post('/', donationController.createDonation.bind(donationController));
router.get('/', donationController.getAllDonations.bind(donationController));
router.get('/:id', donationController.getDonation.bind(donationController));
router.get('/user/:uid', donationController.getDonationsByUser.bind(donationController));
router.put('/:id', donationController.updateDonation.bind(donationController)); 
router.put('/:id/status', donationController.updateDonationStatus.bind(donationController));
router.delete('/:id', donationController.deleteDonation.bind(donationController));
router.put('/:id/reclamado', donationController.updateClaimedStatus.bind(donationController));

module.exports = router;