const express = require('express');
const ProductController = require('../controllers/productController');
const admin = require('../config/firebase');
const multer = require('multer');
const upload = multer({ storage: multer.memoryStorage() });

const router = express.Router();
const productController = new ProductController(admin.firestore());

// Product routes
router.post('/', productController.createProduct.bind(productController));
router.get('/', productController.getAllProducts.bind(productController));
router.get('/donaciones', productController.getDonations.bind(productController)); // <-- Solo donaciones
router.get('/ventas', productController.getSales.bind(productController));         // <-- Solo ventas
router.get('/user/:uid', productController.getProductsByUser.bind(productController));
router.get('/:id', productController.getProduct.bind(productController));
router.delete('/:id', productController.deleteProduct.bind(productController));
router.put('/:id', productController.updateProduct.bind(productController)); 
router.put('/:id/comprar', productController.buyProduct.bind(productController));
router.post('/upload', upload.single('image'), productController.uploadImage.bind(productController));
router.put('/:id/vendido', productController.toggleSoldStatus.bind(productController)); 

module.exports = router;