class DonationController {
    constructor(db) {
        this.db = db;
    }

   async createDonation(req, res) {
        try {
            const { 
                name, 
                category, 
                description, 
                razon, 
                estado, 
                punto, 
                fecha,  // Add fecha field
                hora,   // Add hora field
                uid,
                imageBase64
            } = req.body;

            // Validate required fields
            if (!name || !category || !description || !fecha || !hora) {
                return res.status(400).json({ 
                    error: 'Los campos nombre, categoría, descripción, fecha y hora son obligatorios' 
                });
            }

            // Format date and time
            const fechaHora = new Date(`${fecha}T${hora}`);
            if (isNaN(fechaHora.getTime())) {
                return res.status(400).json({ 
                    error: 'Formato de fecha u hora inválido' 
                });
            }

            const newDonationRef = await this.db.collection('donations').add({
                uid,
                name,
                category,
                description,
                razon,
                estado,
                punto,
                fecha: fechaHora.toISOString(), // Store as ISO string
                imageBase64,
                status: 'disponible',
                createdAt: new Date(),
                updatedAt: new Date()
            });
            
            res.status(201).json({ 
                id: newDonationRef.id, 
                uid,
                name, 
                category, 
                description, 
                razon, 
                estado, 
                punto, 
                fecha: fechaHora.toISOString(),
                status: 'disponible',
                hasImage: !!imageBase64,
                message: 'Donación creada exitosamente'
            });
        } catch (error) {
            console.error('Error creating donation:', error);
            res.status(500).json({ error: 'Error al crear la donación' });
        }
    }

    // Add update method to handle date/time changes
    async updateDonation(req, res) {
        const { id } = req.params;
        const { 
            name, 
            category, 
            description, 
            razon, 
            estado, 
            punto, 
            fecha,
            hora,
            imageBase64 
        } = req.body;

        try {
            // Validate donation exists
            const donationDoc = await this.db.collection('donations').doc(id).get();
            if (!donationDoc.exists) {
                return res.status(404).json({ error: 'Donación no encontrada' });
            }

            // Format date and time if provided
            let fechaHora;
            if (fecha && hora) {
                fechaHora = new Date(`${fecha}T${hora}`);
                if (isNaN(fechaHora.getTime())) {
                    return res.status(400).json({ 
                        error: 'Formato de fecha u hora inválido' 
                    });
                }
            }

            const updateData = {
                updatedAt: new Date()
            };

            // Only update provided fields
            if (name) updateData.name = name;
            if (category) updateData.category = category;
            if (description) updateData.description = description;
            if (razon) updateData.razon = razon;
            if (estado) updateData.estado = estado;
            if (punto) updateData.punto = punto;
            if (fechaHora) updateData.fecha = fechaHora.toISOString();
            if (imageBase64) updateData.imageBase64 = imageBase64;

            await this.db.collection('donations').doc(id).update(updateData);

            const updatedDoc = await this.db.collection('donations').doc(id).get();
            
            res.status(200).json({ 
                id: updatedDoc.id,
                ...updatedDoc.data(),
                message: 'Donación actualizada correctamente'
            });
        } catch (error) {
            console.error('Error updating donation:', error);
            res.status(500).json({ error: 'Error al actualizar la donación' });
        }
    }


    async getDonation(req, res) {
        const { id } = req.params;
        try {
            const donationDoc = await this.db.collection('donations').doc(id).get();
            if (!donationDoc.exists) {
                return res.status(404).json({ error: 'Donación no encontrada' });
            }
            res.status(200).json({ id: donationDoc.id, ...donationDoc.data() });
        } catch (error) {
            res.status(500).json({ error: 'Error al obtener la donación' });
        }
    }

    async getAllDonations(req, res) {
        try {
            const snapshot = await this.db.collection('donations').get();
            const donations = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            res.status(200).json(donations);
        } catch (error) {
            res.status(500).json({ error: 'Error al obtener las donaciones' });
        }
    }

    async getDonationsByUser(req, res) {
        const { uid } = req.params;
        try {
            const snapshot = await this.db.collection('donations')
                .where('uid', '==', uid)
                .get();
            const donations = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            res.status(200).json(donations);
        } catch (error) {
            res.status(500).json({ error: 'Error al obtener las donaciones del usuario' });
        }
    }

async updateDonationStatus(req, res) {
    const { id } = req.params;
    const { status, receptorUid } = req.body;

    try {
        const updateData = {
            status,
            updatedAt: new Date()
        };
        if (status === 'reclamado' && receptorUid) {
            updateData.receptorUid = receptorUid;
        }
        await this.db.collection('donations').doc(id).update(updateData);

        const updatedDoc = await this.db.collection('donations').doc(id).get();
        res.status(200).json({ 
            id: updatedDoc.id, 
            ...updatedDoc.data(),
            message: `Estado de la donación actualizado a: ${status}` 
        });
    } catch (error) {
        res.status(500).json({ error: 'Error al actualizar el estado de la donación' });
    }
    }

    async deleteDonation(req, res) {
        const { id } = req.params;
        try {
            await this.db.collection('donations').doc(id).delete();
            res.status(204).send();
        } catch (error) {
            res.status(500).json({ error: 'Error al eliminar la donación' });
        }
    }
        async updateClaimedStatus(req, res) {
        const { id } = req.params;
        const { reclamado } = req.body;

        try {
            // Validate donation exists
            const donationDoc = await this.db.collection('donations').doc(id).get();
            if (!donationDoc.exists) {
                return res.status(404).json({ error: 'Donación no encontrada' });
            }

            // Update claimed status
            await this.db.collection('donations').doc(id).update({
                reclamado: reclamado,
                updatedAt: new Date()
            });

            // Get updated donation
            const updatedDoc = await this.db.collection('donations').doc(id).get();
            
            res.status(200).json({ 
                id: updatedDoc.id,
                ...updatedDoc.data(),
                message: `Donación marcada como ${reclamado ? 'reclamada' : 'no reclamada'} correctamente`
            });
        } catch (error) {
            console.error('Error updating donation claimed status:', error);
            res.status(500).json({ error: 'Error al actualizar el estado de la donación' });
        }
    }
}

module.exports = DonationController;