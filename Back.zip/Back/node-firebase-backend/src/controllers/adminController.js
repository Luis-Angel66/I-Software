class AdminController {
    constructor(db) {
        this.db = db; // Firebase database instance
    }

    async createAdmin(req, res) {
        const { email, password, name } = req.body;
        try {
            const adminRecord = await this.db.collection('administrators').add({
                email,
                password, // In a real application, ensure to hash the password
                name,
            });
            res.status(201).json({ id: adminRecord.id, email, name });
        } catch (error) {
            res.status(500).json({ error: 'Error creating admin' });
        }
    }

    async getAdmin(req, res) {
        const { id } = req.params;
        try {
            const adminDoc = await this.db.collection('administrators').doc(id).get();
            if (!adminDoc.exists) {
                return res.status(404).json({ error: 'Admin not found' });
            }
            res.status(200).json({ id: adminDoc.id, ...adminDoc.data() });
        } catch (error) {
            res.status(500).json({ error: 'Error fetching admin' });
        }
    }

    async deleteAdmin(req, res) {
        const { id } = req.params;
        try {
            await this.db.collection('administrators').doc(id).delete();
            res.status(204).send();
        } catch (error) {
            res.status(500).json({ error: 'Error deleting admin' });
        }
    }
}

module.exports = AdminController;