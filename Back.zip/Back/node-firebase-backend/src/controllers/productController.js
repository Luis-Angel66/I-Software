class ProductController {
    constructor(db) {
        this.db = db;
    }

    async createProduct(req, res) {
        const { 
            name, 
            category, 
            description, 
            razon, 
            estado, 
            punto, 
            fecha, 
            uid, 
            tipo, 
            imageBase64,
            price // Añadir precio
        } = req.body;

        try {
            // Validar precio
            if (typeof price !== 'number' || price < 0) {
                return res.status(400).json({ 
                    error: 'El precio debe ser un número válido mayor o igual a 0' 
                });
            }

            // Validar tamaño de la imagen (máximo 1MB)
            if (imageBase64 && imageBase64.length > 1000000) {
                return res.status(400).json({ 
                    error: 'La imagen es demasiado grande (máximo 1MB)' 
                });
            }

            const newProductRef = await this.db.collection('products').add({
                uid,
                name,
                category,
                description,
                razon,
                estado,
                punto,
                fecha,
                tipo,
                imageBase64,
                price: Number(price), // Asegurar que se guarda como número
                createdAt: new Date(),
            });
            
            res.status(201).json({ 
                id: newProductRef.id, 
                uid,
                name, 
                category, 
                description, 
                razon, 
                estado, 
                punto, 
                fecha,
                tipo,
                price,
                hasImage: !!imageBase64 
            });
        } catch (error) {
            console.error('Error creating product:', error);
            res.status(500).json({ error: 'Failed to create product' });
        }
    }

    async getProduct(req, res) {
        const { id } = req.params;
        try {
            const productDoc = await this.db.collection('products').doc(id).get();
            if (!productDoc.exists) {
                return res.status(404).json({ error: 'Product not found' });
            }
            res.status(200).json({ id: productDoc.id, ...productDoc.data() });
        } catch (error) {
            res.status(500).json({ error: 'Failed to retrieve product' });
        }
    }

    async deleteProduct(req, res) {
        const { id } = req.params;
        try {
            await this.db.collection('products').doc(id).delete();
            res.status(204).send();
        } catch (error) {
            res.status(500).json({ error: 'Failed to delete product' });
        }
    }

    async getProductsByUser(req, res) {
        const { uid } = req.params;
        try {
            const snapshot = await this.db.collection('products').where('uid', '==', uid).get();
            const products = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            res.status(200).json(products);
        } catch (error) {
            res.status(500).json({ error: 'Failed to retrieve user products' });
        }
    }

    // Nuevo: obtener solo donaciones
    async getDonations(req, res) {
        try {
            const snapshot = await this.db.collection('products').where('tipo', '==', 'donacion').get();
            const donations = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            res.status(200).json(donations);
        } catch (error) {
            res.status(500).json({ error: 'Failed to retrieve donations' });
        }
    }

    // Nuevo: obtener solo ventas
    async getSales(req, res) {
        try {
            const snapshot = await this.db.collection('products').where('tipo', '==', 'venta').get();
            const sales = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            res.status(200).json(sales);
        } catch (error) {
            res.status(500).json({ error: 'Failed to retrieve sales' });
        }
    }

    // Listar todos los productos (ventas y donaciones)
    async getAllProducts(req, res) {
        try {
            const snapshot = await this.db.collection('products').get();
            const products = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            res.status(200).json(products);
        } catch (error) {
            res.status(500).json({ error: 'Failed to retrieve products' });
        }
    }

    async buyProduct(req, res) {
    const { id } = req.params;
    const { compradorUid } = req.body;
    try {
        // Actualiza el producto con el UID del comprador
        await this.db.collection('products').doc(id).update({
            compradorUid: compradorUid
        });
        res.status(200).json({ message: 'Compra realizada correctamente' });
    } catch (error) {
        res.status(500).json({ error: 'No se pudo registrar la compra' });
    }
}

async uploadImage(req, res) {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }

        const bucket = this.storage.bucket('ing-soft-b5bc1.appspot.com');
        const filename = `products/${Date.now()}_${req.file.originalname}`;
        const file = bucket.file(filename);

        const stream = file.createWriteStream({
            metadata: {
                contentType: req.file.mimetype,
            },
        });

        stream.on('error', (error) => {
            console.error('Error uploading image:', error);
            res.status(500).json({ error: 'Failed to upload image' });
        });

        stream.on('finish', async () => {
            // Make the file public
            await file.makePublic();
            
            // Get the public URL
            const imageUrl = `https://storage.googleapis.com/${bucket.name}/${filename}`;
            
            res.status(200).json({ imageUrl });
        });

        stream.end(req.file.buffer);
    } catch (error) {
        console.error('Error in uploadImage:', error);
        res.status(500).json({ error: 'Failed to upload image' });
    }
}

 async updateProduct(req, res) {
        const { id } = req.params;
        const { 
            name, 
            category, 
            description, 
            razon, 
            estado, 
            punto, 
            fecha, 
            imageBase64,
            price 
        } = req.body;

        try {
            // Validate product exists
            const productDoc = await this.db.collection('products').doc(id).get();
            if (!productDoc.exists) {
                return res.status(404).json({ error: 'Producto no encontrado' });
            }

            // Validate price if provided
            if (price !== undefined) {
                if (typeof price !== 'number' || price < 0) {
                    return res.status(400).json({ 
                        error: 'El precio debe ser un número válido mayor o igual a 0' 
                    });
                }
            }

            // Validate image size if provided
            if (imageBase64 && imageBase64.length > 1000000) {
                return res.status(400).json({ 
                    error: 'La imagen es demasiado grande (máximo 1MB)' 
                });
            }

            // Create update object with only provided fields
            const updateData = {};
            if (name) updateData.name = name;
            if (category) updateData.category = category;
            if (description) updateData.description = description;
            if (razon) updateData.razon = razon;
            if (estado) updateData.estado = estado;
            if (punto) updateData.punto = punto;
            if (fecha) updateData.fecha = fecha;
            if (imageBase64) updateData.imageBase64 = imageBase64;
            if (price !== undefined) updateData.price = Number(price);
            updateData.updatedAt = new Date();

            // Update the product
            await this.db.collection('products').doc(id).update(updateData);

            // Get updated product
            const updatedDoc = await this.db.collection('products').doc(id).get();
            
            res.status(200).json({ 
                id: updatedDoc.id,
                ...updatedDoc.data(),
                message: 'Producto actualizado correctamente'
            });
        } catch (error) {
            console.error('Error updating product:', error);
            res.status(500).json({ error: 'Error al actualizar el producto' });
        }
    }
        async toggleSoldStatus(req, res) {
        const { id } = req.params;
        const { vendido } = req.body;

        try {
            // Validate product exists
            const productDoc = await this.db.collection('products').doc(id).get();
            if (!productDoc.exists) {
                return res.status(404).json({ error: 'Producto no encontrado' });
            }

            // Update sold status
            await this.db.collection('products').doc(id).update({
                vendido: vendido,
                updatedAt: new Date()
            });

            // Get updated product
            const updatedDoc = await this.db.collection('products').doc(id).get();
            
            res.status(200).json({ 
                id: updatedDoc.id,
                ...updatedDoc.data(),
                message: `Producto marcado como ${vendido ? 'vendido' : 'no vendido'} correctamente`
            });
        } catch (error) {
            console.error('Error updating product sold status:', error);
            res.status(500).json({ error: 'Error al actualizar el estado de la venta' });
        }
    }
}


module.exports = ProductController;