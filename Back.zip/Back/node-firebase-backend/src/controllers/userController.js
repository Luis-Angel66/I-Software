const fetch = require('node-fetch');

class UserController {
    constructor(admin) {
        this.admin = admin;
        this.auth = admin.auth();
        this.db = admin.firestore();
    }

    async createUser(req, res) {
        const { email, password, displayName, nombre, apellido, telefono, escuela, boleta } = req.body;

        // Validate required fields
        if (!email || !password || !nombre || !apellido) {
            return res.status(400).json({ 
                error: 'Los campos email, password, nombre y apellido son obligatorios' 
            });
        }

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({ 
                error: 'Formato de email inválido' 
            });
        }

        // Validate password length
        if (password.length < 6) {
            return res.status(400).json({ 
                error: 'La contraseña debe tener al menos 6 caracteres' 
            });
        }

        try {
            // Check if user already exists
            try {
                const userExists = await this.auth.getUserByEmail(email);
                if (userExists) {
                    return res.status(400).json({ 
                        error: 'El email ya está registrado' 
                    });
                }
            } catch (error) {
                // User doesn't exist, continue with creation
            }

            // 1. Create user in Firebase Auth
            const userRecord = await this.auth.createUser({
                email,
                password,
                displayName: displayName || `${nombre} ${apellido}`,
            });

            // 2. Save additional data in Firestore
            await this.db.collection('usuarios').doc(userRecord.uid).set({
                uid: userRecord.uid,
                email,
                nombre,
                apellido,
                telefono,
                escuela,
                boleta,
                displayName: displayName || `${nombre} ${apellido}`,
                createdAt: new Date(),
                updatedAt: new Date(),
                lastLogin: null
            });

            // 3. Create custom token
            const token = await this.auth.createCustomToken(userRecord.uid);

            res.status(201).json({ 
                uid: userRecord.uid, 
                email: userRecord.email,
                displayName: userRecord.displayName,
                token,
                message: 'Usuario creado exitosamente'
            });
        } catch (error) {
            console.error('Error creating user:', error);
            res.status(400).json({ 
                error: error.message || 'Error al crear usuario' 
            });
        }
    }

    async loginUser(req, res) {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ 
                error: 'Email y contraseña son requeridos' 
            });
        }

        try {
            const apiKey = process.env.FIREBASE_API_KEY;
            if (!apiKey) {
                throw new Error('FIREBASE_API_KEY no está configurada');
            }

            const response = await fetch(
                `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${apiKey}`,
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        email,
                        password,
                        returnSecureToken: true
                    })
                }
            );
            const data = await response.json();
            
            if (data.error) {
                return res.status(401).json({ 
                    error: 'Credenciales inválidas' 
                });
            }

            // Get user data from Firestore
            const userDoc = await this.db.collection('usuarios').doc(data.localId);
            const userData = await userDoc.get();

            // Update last login
            await userDoc.update({ 
                lastLogin: new Date(),
                updatedAt: new Date()
            });

            res.status(200).json({ 
                idToken: data.idToken,
                refreshToken: data.refreshToken,
                email: data.email,
                uid: data.localId,
                displayName: userData.exists ? userData.data().displayName : null,
                ...(userData.exists && userData.data())
            });
        } catch (error) {
            console.error('Login error:', error);
            res.status(500).json({ 
                error: 'Error al iniciar sesión' 
            });
        }
    }

    async getUser(req, res) {
        const { uid } = req.params;
        
        if (!uid) {
            return res.status(400).json({ 
                error: 'UID es requerido' 
            });
        }

        try {
            const [userRecord, doc] = await Promise.all([
                this.auth.getUser(uid),
                this.db.collection('usuarios').doc(uid).get()
            ]);

            if (!doc.exists) {
                return res.status(404).json({ 
                    error: 'Usuario no encontrado' 
                });
            }

            res.status(200).json({
                uid: userRecord.uid,
                email: userRecord.email,
                displayName: userRecord.displayName,
                ...doc.data()
            });
        } catch (error) {
            res.status(404).json({ 
                error: 'Usuario no encontrado' 
            });
        }
    }

    async updateUser(req, res) {
        const { uid } = req.params;
        const { email, password, nombre, apellido, telefono, escuela, boleta } = req.body;

        if (!uid) {
            return res.status(400).json({ 
                error: 'UID es requerido' 
            });
        }

        try {
            const updates = {};
            const authUpdates = {};

            // Build update objects
            if (email) {
                authUpdates.email = email;
                updates.email = email;
            }
            if (password) authUpdates.password = password;
            if (nombre || apellido) {
                const displayName = `${nombre || ''} ${apellido || ''}`.trim();
                authUpdates.displayName = displayName;
                updates.displayName = displayName;
                if (nombre) updates.nombre = nombre;
                if (apellido) updates.apellido = apellido;
            }
            if (telefono) updates.telefono = telefono;
            if (escuela) updates.escuela = escuela;
            if (boleta) updates.boleta = boleta;

            updates.updatedAt = new Date();

            // Update Auth if needed
            if (Object.keys(authUpdates).length > 0) {
                await this.auth.updateUser(uid, authUpdates);
            }

            // Update Firestore
            await this.db.collection('usuarios').doc(uid).update(updates);

            res.status(200).json({ 
                message: 'Usuario actualizado correctamente',
                updates
            });
        } catch (error) {
            console.error('Update error:', error);
            res.status(400).json({ 
                error: error.message || 'Error al actualizar usuario' 
            });
        }
    }

    async deleteUser(req, res) {
        const { uid } = req.params;

        if (!uid) {
            return res.status(400).json({ 
                error: 'UID es requerido' 
            });
        }

        try {
            await Promise.all([
                this.auth.deleteUser(uid),
                this.db.collection('usuarios').doc(uid).delete()
            ]);
            
            res.status(200).json({ 
                message: 'Usuario eliminado correctamente' 
            });
        } catch (error) {
            res.status(400).json({ 
                error: error.message || 'Error al eliminar usuario' 
            });
        }
    }
}

module.exports = UserController;