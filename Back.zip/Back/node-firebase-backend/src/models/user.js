const { getFirestore } = require('firebase-admin/firestore');

const db = getFirestore();

const userSchema = {
    name: String,
    email: String,
    password: String,
    createdAt: { type: Date, default: Date.now },
};

class User {
    constructor(data) {
        this.name = data.name;
        this.email = data.email;
        this.password = data.password;
        this.createdAt = data.createdAt || new Date();
    }

    static async createUser(data) {
        const user = new User(data);
        const userRef = db.collection('users').doc();
        await userRef.set(user);
        return userRef.id;
    }

    static async getUser(userId) {
        const userRef = db.collection('users').doc(userId);
        const doc = await userRef.get();
        if (!doc.exists) {
            throw new Error('User not found');
        }
        return doc.data();
    }

    static async deleteUser(userId) {
        const userRef = db.collection('users').doc(userId);
        await userRef.delete();
    }
}

module.exports = User;