const { getFirestore } = require('firebase-admin/firestore');

const db = getFirestore();

const productSchema = {
    name: String,
    description: String,
    price: Number,
    stock: Number,
    category: String,
};

class Product {
    constructor(data) {
        this.name = data.name;
        this.description = data.description;
        this.price = data.price;
        this.stock = data.stock;
        this.category = data.category;
    }

    static async create(data) {
        const product = new Product(data);
        const docRef = db.collection('products').doc();
        await docRef.set(product);
        return { id: docRef.id, ...product };
    }

    static async get(id) {
        const docRef = db.collection('products').doc(id);
        const doc = await docRef.get();
        if (!doc.exists) {
            throw new Error('Product not found');
        }
        return { id: doc.id, ...doc.data() };
    }

    static async delete(id) {
        const docRef = db.collection('products').doc(id);
        await docRef.delete();
        return { id };
    }
}

module.exports = Product;