# Node Firebase Backend

This project is a Node.js backend application that utilizes Firebase for authentication and database management. It is designed to support a website built with HTML, featuring user, administrator, and product management functionalities.

## Project Structure

```
node-firebase-backend
├── src
│   ├── app.js               # Entry point of the application
│   ├── config
│   │   └── firebase.js      # Firebase configuration and initialization
│   ├── controllers
│   │   ├── adminController.js  # Controller for administrator operations
│   │   ├── productController.js # Controller for product operations
│   │   └── userController.js    # Controller for user operations
│   ├── models
│   │   ├── admin.js          # Admin model definition
│   │   ├── product.js        # Product model definition
│   │   └── user.js           # User model definition
│   ├── routes
│   │   ├── adminRoutes.js    # Routes for administrator-related operations
│   │   ├── productRoutes.js   # Routes for product-related operations
│   │   └── userRoutes.js      # Routes for user-related operations
│   └── utils
│       └── index.js          # Utility functions
├── package.json               # NPM configuration file
└── README.md                  # Project documentation
```

## Setup Instructions

1. **Clone the repository:**
   ```
   git clone <repository-url>
   cd node-firebase-backend
   ```

2. **Install dependencies:**
   ```
   npm install
   ```

3. **Configure Firebase:**
   - Create a Firebase project in the Firebase console.
   - Obtain your Firebase configuration and update `src/config/firebase.js` accordingly.

4. **Run the application:**
   ```
   npm start
   ```

## Usage Guidelines

- The application provides RESTful APIs for managing users, administrators, and products.
- Use the appropriate routes defined in `src/routes` to interact with the application.
- Ensure that Firebase authentication is properly set up to secure the endpoints.

## Contributing

Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.